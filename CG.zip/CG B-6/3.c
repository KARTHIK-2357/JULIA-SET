#include <GL/glut.h>
#include <stdio.h>
#include <math.h>

// Window size
#define WIDTH 800
#define HEIGHT 800

// Parameters for Julia set
double c_real = -0.7;
double c_imaginary = 0.27015;

// Function to calculate Julia set
int juliaSet(double real, double imaginary) {
    int maxIterations = 200;
    int iterations = 0;
    double z_real = real;
    double z_imaginary = imaginary;

    while (iterations < maxIterations) {
        double z_real_squared = z_real * z_real;
        double z_imaginary_squared = z_imaginary * z_imaginary;

        // Check if the point is outside the bounded region
        if (z_real_squared + z_imaginary_squared > 4.0) {
            return iterations;
        }

        // Calculate the new value of z
        double new_z_real = z_real_squared - z_imaginary_squared + c_real;
        double new_z_imaginary = 2 * z_real * z_imaginary + c_imaginary;

        z_real = new_z_real;
        z_imaginary = new_z_imaginary;

        iterations++;
    }

    return iterations;
}

// Function to render the Julia set
void render() {
    glClearColor(0.0, 0.0, 0.0, 1.0);
    glClear(GL_COLOR_BUFFER_BIT);

    glMatrixMode(GL_PROJECTION);
    glLoadIdentity();
    gluOrtho2D(-2.0, 2.0, -2.0, 2.0);

    glBegin(GL_POINTS);

    for (int x = 0; x < WIDTH; x++) {
        for (int y = 0; y < HEIGHT; y++) {
            double real = (x - WIDTH / 2.0) / (WIDTH / 4.0);
            double imaginary = (y - HEIGHT / 2.0) / (HEIGHT / 4.0);

            int iterations = juliaSet(real, imaginary);

            double color = iterations / 200.0;
            glColor3f(color, color, color);
            glVertex2f(real, imaginary);
        }
    }

    glEnd();
    glFlush();
}

// Keyboard callback function
void keyboard(unsigned char key, int x, int y) {
    switch (key) {
        case 'q': // Increase the real part of c
            c_real += 0.1;
            break;
        case 'a': // Decrease the real part of c
            c_real -= 0.1;
            break;
        case 'w': // Increase the imaginary part of c
            c_imaginary += 0.1;
            break;
        case 's': // Decrease the imaginary part of c
            c_imaginary -= 0.1;
            break;
        case 27: // Escape key to exit
            exit(0);
    }

    glutPostRedisplay();
}

int main(int argc, char** argv) {
    glutInit(&argc, argv);
    glutInitDisplayMode(GLUT_RGB);
    glutInitWindowSize(WIDTH, HEIGHT);
    glutCreateWindow("Julia Set");

    glutDisplayFunc(render);
    glutKeyboardFunc(keyboard);

    glutMainLoop();

    return 0;
}
