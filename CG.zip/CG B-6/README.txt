PRESS q real part = +0.1
PRESS a real part = -0.1
PRESS w imaginary part = +0.1
PRESS w imaginary part = -0.1
